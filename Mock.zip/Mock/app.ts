interface EventData {
    name: string;
    category: string;
    date: string;
}

document.addEventListener('DOMContentLoaded', () => {
    const eventContainer = document.getElementById('event-container') as HTMLElement;
    const categoryFilter = document.getElementById('category-filter') as HTMLSelectElement;
    const dateFilter = document.getElementById('date-filter') as HTMLInputElement;

    let events: EventData[] = [];

    // Fetch events
    const fetchEvents = async (): Promise<void> => {
        try {
            const response = await fetch('mock-events.json');
            if (!response.ok) throw new Error('Network response was not ok');
            events = await response.json();
            renderEvents(events);
        } catch (error) {
            console.error('Error fetching events:', error);
            eventContainer.innerHTML = '<p>Error loading events. Please try again later.</p>';
        }
    };

    // Filter events
    const filterEvents = (): void => {
        const selectedCategory = categoryFilter.value;
        const selectedDate = dateFilter.value;
        let filteredEvents = events;

        if (selectedCategory) {
            filteredEvents = filteredEvents.filter(event => event.category === selectedCategory);
        }
        if (selectedDate) {
            filteredEvents = filteredEvents.filter(event => event.date === selectedDate);
        }

        renderEvents(filteredEvents);
    };

    categoryFilter.addEventListener('change', filterEvents);
    dateFilter.addEventListener('change', filterEvents);

    fetchEvents();
});

function renderEvents(eventList: EventData[]): void {
    const eventContainer = document.getElementById('event-container') as HTMLElement;
    eventContainer.innerHTML = '';

    if (eventList.length === 0) {
        eventContainer.innerHTML = '<p>No events found.</p>';
        return;
    }

    eventList.forEach(event => {
        const card = `
            <div class="card mb-3">
                <div class="card-body">
                    <h5>${event.name}</h5>
                    <p><strong>Category:</strong> ${event.category}</p>
                    <p><strong>Date:</strong> ${event.date}</p>
                </div>
            </div>
        `;
        eventContainer.innerHTML += card;
    });
}
